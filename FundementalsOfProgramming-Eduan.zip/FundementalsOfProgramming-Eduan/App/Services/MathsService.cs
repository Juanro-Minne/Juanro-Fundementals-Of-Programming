﻿using Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Services
{
    public class MathsService : IMathsService
    {
        public string FactorialCalc(int number)
        {
            double fact = number;
        
            fact = number;
            for (int i = number - 1; i >= 1; i--)
            {
                fact = fact * i;
            }
            double answer =( fact);
            return "The answer of the factorial is "+ answer;
        }
    }
}
