﻿using Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Services
{
    public class ReverseService : IReverseService
    {
        public string ReverseString(string sentence)
        {
            string[] arraySentence = sentence.Split(' ');
            string reversedSentence = "";

            for (int i = arraySentence.Length - 1; i >= 0; i--)
            {
                reversedSentence += arraySentence[i] + " ";
            }

            string answer = "Reversed String: " + reversedSentence.TrimEnd();
            return answer;
        }

    }
}
