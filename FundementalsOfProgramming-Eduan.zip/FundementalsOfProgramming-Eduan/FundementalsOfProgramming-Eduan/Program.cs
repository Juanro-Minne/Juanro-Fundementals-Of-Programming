
using Services.Interfaces;
using Adapters;
using Services.Services;

namespace FundementalsOfProgramming_Eduan
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddScoped<IimageService, ImageService>();
            builder.Services.AddScoped<IimageAdapter, ImageAdapter>();
            builder.Services.AddScoped<MathsService, MathsService>();
            builder.Services.AddScoped<IReverseService, ReverseService>();

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
