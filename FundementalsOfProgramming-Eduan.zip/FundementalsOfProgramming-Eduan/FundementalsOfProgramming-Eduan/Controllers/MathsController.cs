﻿using Microsoft.AspNetCore.Http;
using Services.Interfaces;
using Services.Services;
using Microsoft.AspNetCore.Mvc;

namespace FundementalsOfProgramming_Eduan.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class MathsController : ControllerBase
    {
        private readonly MathsService _mathsService;

        public  MathsController(MathsService mathsService) 
        {
            _mathsService = mathsService;
        }

        [HttpGet]
        public string FactorialCalc(int number)
        {
            return _mathsService.FactorialCalc(number);
        }
    }
}
