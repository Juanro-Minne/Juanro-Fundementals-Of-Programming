﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services.Interfaces;
using Services.Services;

namespace FundementalsOfProgramming_Eduan.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class ImageGenrateController : ControllerBase
    {
        private  readonly IimageService _imageService;

        public ImageGenrateController(IimageService ImageService) 
        { 
            _imageService = ImageService;
        }


        [HttpGet]
        public string GeneratedDogImage()
        {
            return _imageService.GenerateDog();
        }
    }
}
