﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services.Interfaces;
using Services.Services;

namespace FundementalsOfProgramming_Eduan.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class ReverseController : ControllerBase
    {
        private readonly IReverseService _reverseService;

        public ReverseController(IReverseService reverseService)
        {
            _reverseService = reverseService;
        }

        [HttpGet]
        public string ReverseString(string unreversed) 
        {
            return _reverseService.ReverseString(unreversed);
        }
    }
}
    